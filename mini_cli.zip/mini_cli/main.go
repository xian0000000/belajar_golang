package main

import (
	"belajar_golang/mini_cli/fungsi"
)

func main() {
	fungsi.Main_Loop()
}
